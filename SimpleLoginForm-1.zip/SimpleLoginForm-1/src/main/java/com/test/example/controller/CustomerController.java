package com.test.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.test.example.modal.entity.AuthRequest;
import com.test.example.modal.entity.AuthResponse;
import com.test.example.modal.entity.Customer;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    private RestTemplate restTemplate;

    private String baseUrl = "https://qa2.sunbasedata.com/sunbase/portal/api/";

    private String authToken = null;

    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticateUser() {
        String authUrl = baseUrl + "assignment_auth.jsp";
        String loginId = "test@sunbasedata.com";
        String password = "Test@123";

        AuthRequest authRequest = new AuthRequest(loginId, password);
        AuthResponse authResponse = restTemplate.postForObject(authUrl, authRequest, AuthResponse.class);

        if (authResponse != null && authResponse.getToken() != null) {
            authToken = authResponse.getToken();
            return ResponseEntity.ok(authToken);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Authorization");
        }
    }

    @PostMapping("/createCustomer")
    public ResponseEntity<String> createCustomer(@RequestHeader("Authorization") String token,
                                                 @RequestBody Customer customer) {
        if (!token.equals("Bearer " + authToken)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Authorization");
        }

        if (customer.getFirstName() == null || customer.getLastName() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("First Name or Last Name is missing");
        }

        String createUrl = baseUrl + "assignment.jsp?cmd=create";
        ResponseEntity<String> createResponse = restTemplate.postForEntity(createUrl, customer, String.class);

        if (createResponse.getStatusCode() == HttpStatus.CREATED) {
            return ResponseEntity.status(HttpStatus.CREATED).body("Successfully Created");
        } else {
            return ResponseEntity.status(createResponse.getStatusCode()).body(createResponse.getBody());
        }
    }

    @GetMapping("/getCustomers")
    public ResponseEntity<List<Customer>> getCustomers(@RequestHeader("Authorization") String token) {
        if (!token.equals("Bearer " + authToken)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }

        String getCustomersUrl = baseUrl + "assignment.jsp?cmd=get_customer_list";
        ResponseEntity<Customer[]> responseEntity = restTemplate.getForEntity(getCustomersUrl, Customer[].class);

        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            Customer[] customersArray = responseEntity.getBody();
            List<Customer> customers = new ArrayList<>();
            for (Customer customer : customersArray) {
                customers.add(customer);
            }
            return ResponseEntity.ok(customers);
        } else {
            return ResponseEntity.status(responseEntity.getStatusCode()).body(null);
        }
    }

    @PostMapping("/deleteCustomer")
    public ResponseEntity<String> deleteCustomer(@RequestHeader("Authorization") String token,
                                                 @RequestParam("uuid") String uuid) {
        if (!token.equals("Bearer " + authToken)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Authorization");
        }

        String deleteUrl = baseUrl + "assignment.jsp?cmd=delete&uuid=" + uuid;
        ResponseEntity<String> deleteResponse = restTemplate.postForEntity(deleteUrl, null, String.class);

        if (deleteResponse.getStatusCode() == HttpStatus.OK) {
            return ResponseEntity.ok("Successfully deleted");
        } else {
            return ResponseEntity.status(deleteResponse.getStatusCode()).body(deleteResponse.getBody());
        }
    }

    @PostMapping("/updateCustomer")
    public ResponseEntity<String> updateCustomer(@RequestHeader("Authorization") String token,
                                                 @RequestParam("uuid") String uuid,
                                                 @RequestBody Customer customer) {
        if (!token.equals("Bearer " + authToken)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Authorization");
        }

        if (customer.getFirstName() == null || customer.getLastName() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("First Name or Last Name is missing");
        }

        String updateUrl = baseUrl + "assignment.jsp?cmd=update&uuid=" + uuid;
        ResponseEntity<String> updateResponse = restTemplate.postForEntity(updateUrl, customer, String.class);

        if (updateResponse.getStatusCode() == HttpStatus.OK) {
            return ResponseEntity.ok("Successfully Updated");
        } else {
            return ResponseEntity.status(updateResponse.getStatusCode()).body(updateResponse.getBody());
        }
    }
}
